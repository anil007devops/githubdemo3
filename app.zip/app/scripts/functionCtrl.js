(function(){

'use strict';
angular
    .module('app')
    .controller('LoginController',loginCtrl)
    .controller('SignupController',signupCtrl)
    .controller('AddressbookController', addressBookCtrl)
    .controller('ContactController',addcontactCtrl);


    loginCtrl.$inject = ['$scope','$location','$http','$rootScope'];
    function loginCtrl($scope,$location,$http,$rootScope){


      var vm = $scope;
      vm.user = {};
      vm.loginError = "";


      vm.login = function(){

console.log(vm.user);

$http.post("http://localhost:4516/api/users/login", vm.user)
     .then (function(response){

       console.log(JSON.stringify(response));
       $rootScope.user = response;
       if(response){

        $location.path("/addressbook");
       }

     },function(response){

       vm.loginError = "Email or password is wrong";

     });

      }

    };

/*signup function */
signupCtrl.$inject = ['$scope','$location','$http','$rootScope'];
function signupCtrl($scope,$location,$http,$rootScope){

  var vm = $scope;
  vm.user = {};

  vm.signup = function(){
//console.log(vm.user);
    $http.post("http://localhost:4516/api/users",{
         email: vm.user.email,
         password:vm.user.password,
         name:vm.user.username

    })
      .then (function (response){
        //  console.log(JSON.stringify(response));
          if(response){

            $location.path("/login");
          }
        },function(response){
          //log error
        });
      }
};


/*addressBook function */
addressBookCtrl.$inject = ['$scope','$location','$http','$rootScope'];
function addressBookCtrl($scope,$location,$http,$rootScope){

  var vm = $scope;
  vm.user = {};

  vm.addressBook = function(){
//console.log(vm.user);
    $http.post("http://localhost:4516/api/AddressBooks",{

         name:vm.user.username

    })
      .then (function (response){
        //  console.log(JSON.stringify(response));
          if(response){

            $location.path("/contact");
          }
        },function(response){
          //log error
        });
      }
};


/*addContactCtrl function */
addcontactCtrl.$inject = ['$scope','$location','$http','$rootScope'];
function addcontactCtrl($scope,$location,$http,$rootScope){

  var vm = $scope;
  vm.user1 = {};

  vm.addcontact = function(){
console.log(vm.user1);

    $http.post("http://localhost:4516/api/Contacts",{
         email: vm.user1.email,
         city:vm.user1.city,
         name:vm.user1.username,
         company:vm.user1.company,
         state:vm.user1.state

    })
      .then (function (response){
        console.log(JSON.stringify(response));
          if(response){

console.log(vm.user1);
            $location.path("/thank");
          }
        },function(response){
          //log error
        });
      }
};






})();
