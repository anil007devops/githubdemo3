(function(){

'use strict';
angular
    .module('app')
    .controller('LoginController',loginCtrl)
    .controller('SignupController',signupCtrl)
    .controller('AddressbookController', addressBookCtrl)
    .controller('ContactController',addcontactCtrl)
    .controller('LogoutController',logoutCtrl);


    loginCtrl.$inject = ['$scope','$location','$http','$rootScope'];
    function loginCtrl($scope,$location,$http,$rootScope){


      var vm = $scope;
      vm.user = {};
      vm.loginError = "";


      vm.login = function(){

console.log(vm.user);

$http.post("http://localhost:4516/api/users/login", vm.user)
     .then (function(response){

       console.log(JSON.stringify(response));
       $rootScope.user = response.data.id; /* this is the rootScope we can use it anywhere to get userId */
       console.log(response.data.id);
       if(response){

        $location.path("/addressbook");
       }

     },function(response){

       vm.loginError = "Email or password is wrong";

     });

      }

    };

/*signup function */
signupCtrl.$inject = ['$scope','$location','$http','$rootScope'];
function signupCtrl($scope,$location,$http,$rootScope){

  var vm = $scope;
  vm.user = {};

  vm.signup = function(){
//console.log(vm.user);
    $http.post("http://localhost:4516/api/users",{
         email: vm.user.email,
         password:vm.user.password,
         name:vm.user.username

    })
      .then (function (response){
        //  console.log(JSON.stringify(response));
          if(response){

            $location.path("/login");
          }
        },function(response){
          //log error
        });
      }
};





/*fetch records from addressBook */
addressBookCtrl.$inject = ['$scope','$location','$http','$rootScope'];
function addressBookCtrl($scope,$location,$http,$rootScope){
  //console.log("addressBookCtrl......");

  var vm = $scope;
  vm.addresBook = {};
  vm.addresBookData = {};

  vm.getAddressBook = function() {
    $http.get("http://localhost:4516/api/AddressBooks")
      .then (function (res){
       // console.log(res);
        vm.addresBook = res.data;          
        },function(err){
          console.log(err);
          //log error
        });
  }

  vm.getAddressBook();  


//add addressbook records
  vm.addressBook = function(){


  $http.post("api/AddressBooks", vm.addresBookData)
    .then (function (res){
     // console.log(JSON.stringify(res));          
      alert("address book added successfully!!"); 
      vm.getAddressBook();       
    },function(err){
      console.log(err);
    });
  }


  vm.deleteAddressBook = function(id){
    $http.delete("api/AddressBooks/" + id)
      .then (function (response){
       // console.log(JSON.stringify(response));
        vm.getAddressBook();
      },function(response){
          //log error
      });
  }

vm.setAddressbook = function(data)
{

  vm.addresBookData1 = data;
  //console.log(data);
};

 vm.saveAddressBook = function(){
   //console.log( vm.addresBookData1);
    $http.put("api/AddressBooks/" ,vm.addresBookData1)
      .then (function (response){
        console.log(JSON.stringify(response));
        alert("successfully done!!");
        vm.getAddressBook();
      },function(response){
          //log error
      });
  }



}; /*end of main function */




/*addContactCtrl function */
addcontactCtrl.$inject = ['$scope','$location','$http','$rootScope','$stateParams','$animate'];
function addcontactCtrl($scope,$location,$http,$rootScope,$stateParams,$animate){

  var vm = $scope;
  vm.contactBook = {}; /* create json */
  vm.contactBook.addressBookId = $stateParams.id; /* setting addressBookId to json*/
  vm.contactBook.createdById = $rootScope.user; /* user id (createdBYId)  */
 var currentId = $stateParams.id;
var vm = $scope;
  vm.adData = {};
 

/* get contact code */
  vm.getContact = function() {
    $http.get("api/AddressBooks/"+currentId+"/contacts")
      .then (function (res){
       // console.log(res);
        vm.adData = res.data;
        // console.log(vm.adData);
        },function(err){
          console.log(err);
          //log error
        });
  }

  vm.getContact();  


/* add contact code */
vm.addContact = function(){
//console.log(currentId);
  $http.post("api/AddressBooks/" + currentId + "/contacts", vm.contactBook)
    .then (function (res){
    
     //console.log(JSON.stringify(res));          
      alert("Contact added successfully!!"); 
      vm.getContact();       
    },function(err){
      console.log(err);
    });
  }



/* delete contact code*/
vm.deleteContact = function(id){
    $http.delete("api/Contacts/" + id)
      .then (function (response){
       console.log(JSON.stringify(response));
        vm.getContact();
      },function(response){
          //log error
      });
  }



vm.setContactBook = function(data)
{

  vm.addContactBook1 = data;
  console.log(data);
};

 vm.saveContactBook = function(){
   console.log( "hello");
    $http.put("api/Contacts/" , vm.addContactBook1)
      .then (function (response){
        //console.log(JSON.stringify(response));
        alert("successfully done!!");
        vm.getContact();
      },function(response){
          //log error
      });
  }


/*sorting function */
$scope.orderField = "firstName";
    $scope.reverse    = false;

 $scope.doSort = function (sortType, reverse) {
        console.log('sorting',sortType, reverse);
        $scope.orderField = sortType;
        $scope.reverse    = !$scope.reverse;
    }


//for search filter
 $scope.query = {};

    $scope.queryBy = '$';
 $scope.orderProp="firstName";  

};



/*logout function */
logoutCtrl.$inject = ['$scope','$location','$http','$rootScope'];
function logoutCtrl($scope,$location,$http,$rootScope){
 var vm = $scope;


 vm.logout = function(){
   //console.log( vm.addContactBook);
    $http.post("api/users/logout")
      .then (function (response){
        console.log(JSON.stringify(response));
         $location.path("/logout");
      },function(response){
          //log error
      });
  }
};


})();
