(function (){

'use strict';

angular
.module('app')
.config(config);

config.$inject = ['$stateProvider','$urlRouterProvider'];
function config ($stateProvider,$urlRouterProvider){


  $urlRouterProvider
  .otherwise('/login');

  $stateProvider

  .state('login',{
  url:'/login',
  templateUrl:'modules/user/views/user-login.html',
  controller:'LoginController',

  })

  .state('signup',{
  url:'/signup',
  templateUrl:'modules/user/views/user-signup.html',
  controller:'SignupController',

  })

  .state('contact',{
  url:'/contact',
  templateUrl:'modules/user/views/contact.html',
  controller:'',

  })


  .state('addressbook',{
  url:'/addressbook',
  templateUrl:'modules/user/views/addressBook.html',
  controller:'AddressbookController',

  })


  .state('thank',{
  url:'/thank',
  templateUrl:'modules/user/views/thankyou.html',
  controller:'ContactController',

  })


}

})();
