<?php echo $__env->make('includes.header2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="css/signin.css" rel="stylesheet">
<div class="container">

    <!-- this below small code is used for checking error while login -->
    <?php if(Session::has('fail')): ?>
        <section class="info-box fail">
            <?php echo e(Session::get('fail')); ?>

        </section>
    <?php endif; ?>


    <?php if(Session::has('success')): ?>
        <section class="info-box success">
            <?php echo e(Session::get('success')); ?>

        </section>
    <?php endif; ?>

    <?php if(count($errors)>0): ?>
        <section class="info-box fail">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </section>
    <?php endif; ?>
<!-- -->

    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <div class="well center_div">

                <form class="form-signin" method="post"  action="<?php echo e(route('admin.login2')); ?>">
                    <h2 class="form-signin-heading"><img src="images/copy.jpg" class="img-responsive"/></h2>
                    <div class="input-group">
                        <label for="email" class="sr-only">Email address</label>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="email" name="email" id="email" <?php echo e($errors->has('email') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('email')); ?>" class="form-control" placeholder="Email address" required autofocus>
                    </div>
                    <div class="input-group">
                        <label for="password" class="sr-only">Password</label>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input type="password" name="password" id="password" <?php echo e($errors->has('password') ? 'class=has-error' : ''); ?> class="form-control" placeholder="Password" >
                    </div>
                    <br>
                    <div class="col-sm-6">
                        <label>
                            <input type="checkbox" value="remember-me"> Remember
                        </label>
                    </div>

                    <div class="col-sm-6">

                        <a  href="#">Forgot Password?</a>

                    </div>
                    <br><br>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"/>
                </form>


            </div>

        </div>
        <div class="col-sm-3"></div>
    </div>


</div>


