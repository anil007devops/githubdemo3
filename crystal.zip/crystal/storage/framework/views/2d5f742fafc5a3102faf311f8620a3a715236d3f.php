<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<?php $__env->startSection('content'); ?>

    <div class="centered">

        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

            <a href="<?php echo e(route('niceaction',['action'=> lcfirst($action->name)])); ?>"><?php echo e($action->name); ?></a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<br><br>

        <?php if(count($errors) >0): ?>
            <div>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                        <?php echo e($error); ?>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </ul>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('add_action')); ?>" method="post">



            <label for="name">Name of Action</label>
            <input type="text" name="name" id="name"/>

            <label for="niceness">Niceness</label>
            <input type="text" name="niceness" id="niceness"/>

            <button type="submit" onclick="send(event)">Submit</button>
            <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">

        </form>

        <br><br><br>

            <ul>
                <?php $__currentLoopData = $logged_actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logged_action): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                   <li> <?php echo e($logged_action->nice_action->name); ?>


                   <?php $__currentLoopData = $logged_action->nice_action->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                      <?php echo e($category->name); ?>

                       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                   </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </ul>

            <?php if($logged_actions->lastPage()>1): ?>
                <?php for($i=1;$i<=$logged_actions->lastPage();$i++): ?>

                   <a href="<?php echo e($logged_actions->url($i)); ?>" > <?php echo e($i); ?> </a>
                    <?php endfor; ?>
            <?php endif; ?>
        <script type="text/javascript">

            function send(event) {

                event.preventDefault();
                $.ajax({

                    type: "POST",
                    url: "<?php echo e(route('add_action')); ?> ",
                    data: {name: $("#name").val(),niceness: $("#niceness").val(),_token: "<?php echo e(Session::token()); ?>" }

                })
            }

        </script>




    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>