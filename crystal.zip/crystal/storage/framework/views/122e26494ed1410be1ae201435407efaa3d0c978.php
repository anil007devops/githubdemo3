<header class="top-nav">
    <nav>
        <ul>
            <li><a href="">DashBoard</a></li>
            <li ><a href="">Posts</a></li>
            <li ><a href="">Categories</a></li>
            <li ><a href="">Contact Messages</a></li>
            <li><a href="">Logout</a></li>
        </ul>
    </nav>
</header>