<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\User;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/index';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('guest', ['except' => 'logout']);
    }

    public function postLogin(Request $request){

        // $admin = DB::table('admins')->get();  // we can also return $admin in response as whole object as per requirement

        //setting the cradential array
        $cradentials = [
            'email'=>$request->input('email'),
            'password'=> $request->input('password'),
        ];

        //if the cradentials are wrong
        if(!Auth::attempt($cradentials)){
            return response('Email or password does not match',403);
        }
        return response('successfully login with cradentials ' . implode(" ",$cradentials));
    }


}
