<?php

namespace App\Http\Controllers;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Response;
class AuthController extends Controller
{


    public function getIndex(){
//        //fetch posts & messages
//        $posts = Post::orderBy('created_at','desc')->take(3)->get();
//        $contact_messages = ContactMessage::orderBy('created_at','desc')->take(3)->get();
//        return view('admin.index',['posts'=>$posts,'contact_messages'=>$contact_messages]);
    }

//    public function getLogin(){
//        return view('login');
//    }

    public function postLogin(Request $request){

      $id= Auth::id();
     //$user = User::with('roles')->get();  // we can also return $user in response as whole object as per requirement

$user = DB::table('users')
        ->join('roles','users.id','=','roles.user_id')
       ->select('roles.role_name')->where('users.id','=',$id)->get();
        //setting the cradential array
        $cradentials = [
            'email'=>$request->input('email'),
            'password'=> $request->input('password'),
        ];

        //if the cradentials are wrong
        if(!Auth::attempt($cradentials,true)){
            return response('Email or password does not match',403);
        }
       return $user->toJson();
        //$data = \App\User::with('roles')->findOrFail(1);
       //return new JsonResponse($user1);
       // return Response::json(['user' => Auth::id()], 202); //here user() is the object
      // return Response::json(['user' => $user->toArray()], 202); //here user() is the object
       //return response('successfully login with cradentials ' .implode(" ",$user1));
    }

    public function getLogout(){

       Auth::logout();
        Session::flush();

            return Response::json([
                'logout' => 'you have been disconnected'],
                200
            );


    }

}

