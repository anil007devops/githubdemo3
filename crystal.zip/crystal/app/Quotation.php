<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quotation extends Model
{
   public function customer(){

      // return $this->belongsToMany('App\Customer','customers');
   }

}
