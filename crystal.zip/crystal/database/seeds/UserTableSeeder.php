<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Role;
class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $user = new User();
        $user->first_name = 'Anil';
        $user->last_name = 'Prajapat';
        $user->email = 'ani@gmail.com';
        $user->phone_no = '9826698676';
        $user->company_name = 'Zehntech';
        $user->password = \Hash::make('ani143');
        $user->address = '504-Shekhar central,Plasia';
        $user->city = 'Indore';
        $user->state = 'MP';
        $user->zipcode = '452005';
        $user->save();


        $admin = new User();
        $admin->first_name = 'Sunil';
        $admin->last_name = 'Prajapat';
        $admin->email = 'sunil@gmail.com';
        $admin->phone_no = '9826658412';
        $admin->company_name = 'Apna Sweets';
        $admin->password = \Hash::make('sunil143');
        $admin->address = '54-Kanyakubj nagar';
        $admin->city = 'Indore';
        $admin->state = 'MP';
        $admin->zipcode = '452005';
        $admin->save();

    }
}
