
<?php include 'header.html';?>

<!-- Table-to-load-the-data Part -->
<table class="table">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact No</th>
        <th>Address</th>
        <th><button id="btn-add" class="btn btn-primary btn-xs" ng-click="toggle('add', 0)">Add New Employee</button></th>
    </tr>
    </thead>
    <tbody>
    <tr ng-repeat="customer in customers">
        <td>{{  customer.id }}</td>
        <td>{{ customer.first_name }}</td>
        <td>{{ customer.email }}</td>
        <td>{{ customer.phone_no }}</td>
        <td>{{ customer.address }}</td>
        <td>
            <button class="btn btn-default btn-xs btn-detail" ng-click="toggle('edit', customer.id)">Edit</button>
            <button class="btn btn-danger btn-xs btn-delete" ng-click="confirmDelete( customer.id)">Delete</button>

        </td>
    </tr>
    </tbody>
</table>
<div class="container">
    <div class="col-sm-2"><a href="#/logout">Logout</a></div>
</div>
