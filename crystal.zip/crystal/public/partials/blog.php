<?php include 'header.html';?>

<h2>This is blog post page</h2>

<div class="container">
    <div class="col-sm-2"><a href="#/logout">Logout</a></div>
</div>

