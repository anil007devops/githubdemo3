(function (){

'use strict';

angular
.module('App')
.config(config);

config.$inject = ['$stateProvider','$urlRouterProvider'];
function config ($stateProvider,$urlRouterProvider){


  $urlRouterProvider
      .otherwise('/');

  $stateProvider

      .state('login',{
        url:'/login',
        templateUrl:'partials/login.php',
        controller:'LoginController',

      })

      .state('signup',{
        url:'/signup',
        templateUrl:'partials/signup.php',
        controller:'SignupController',

      })

      .state('/',{
        url:'/',
        templateUrl:'partials/home.php',
        controller:'',

      })

      .state('/about',{
        url:'/about',
        templateUrl:'partials/about.php',
        controller:'MainController',

      })

      .state('/blog',{
        url:'/blog',
        templateUrl:'partials/blog.php',
        controller:'',

      })
      .state('/contact',{
        url:'/contact',
        templateUrl:'partials/contact.php',
        controller:'',

      })

      .state('/logout',{
          url:'/logout',
          templateUrl:'partials/login.php',
          controller:'LogoutController',

      })

}

})();
