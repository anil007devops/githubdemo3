<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{

    public function quotes(){

        return $this->hasMany('App\Quotation','quotations');  //here quotation is table name
    }
}
