<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Admin;
class AdminController extends Controller
{

    public function getIndex(){
//        //fetch posts & messages
//        $posts = Post::orderBy('created_at','desc')->take(3)->get();
//        $contact_messages = ContactMessage::orderBy('created_at','desc')->take(3)->get();
//        return view('admin.index',['posts'=>$posts,'contact_messages'=>$contact_messages]);
    }

    public function getLogin(){
        return view('login2');
    }

    public function postLogin(Request $request){

          //setting the cradential array
        $cradentials = [
            'email'=>$request->input('email'),
            'password'=> $request->input('password'),
        ];

      //if the cradentials are wrong
        if(!Auth::attempt($cradentials)){
            return response('Email or password does not match',403);
        }
        return response(Auth::user(),201);
    }

    public function getLogout(){

//        Auth::logout();
//        return redirect()->route('views.index');
    }

}

