<?php $__env->startSection('title'); ?>
    About me
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>My name is....</h1>
    <p>
        Successful bloggers have to keep their heads around many different aspects of the medium – but at it’s core is being able to write compelling and engaging content on a consistent basis over time.

        How you do this will vary from blogger to blogger to some extent as each blogger has their own style – however there are some basic principles of writing great blog content that might be worth keeping in mind.

        Below are a few of the lessons I’ve learned on the topic over the years.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>