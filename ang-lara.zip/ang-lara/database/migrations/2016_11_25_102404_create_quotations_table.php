<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateQuotationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('quotations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('customer_id');
            $table->string('lease_type');
            $table->string('copier_type');
            $table->integer('no_of_boxes');
            $table->string('copier_required');
            $table->integer('no_of_copier');
            $table->string('another_lease');
            $table->string('cancel_lease');
            $table->date('expire_lease');
            $table->string('paper_type');
            $table->string('interest');
            $table->string('decision');
            $table->string('accessories');
            $table->string('plan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quotations');
    }
}
