(function(){

    'use strict';
    angular
        .module('bookWishlistApp')
        .controller('LoginController',loginCtrl)
        .controller('SignupController',signupCtrl)
        .controller('MainController', mainCtrl);



    loginCtrl.$inject = ['$scope','$location','$http','$rootScope'];
    function loginCtrl($scope,$location,$http,$rootScope){


        // var vm = $scope;
        // vm.user = {};
        // vm.loginError = "";
        console.log(user);

        vm.login = function(loginForm){


$http({

    headers:{
        'content-Type': 'application/json'
    },
    url: baseUrl + 'auth',
    method: "POST",
    data: {
        email:$scope.user.email,
        password:$scope.user.password
    }
}).success(function(response){
    console.log(response);
    $location.path('/about');
}).error(function(data,status,headers){
    console.log(data,status,headers);
    alert(data);
});

        }

    }



    signupCtrl.$inject = ['$scope','$location','$http','$rootScope'];
    function signupCtrl($scope,$location,$http,$rootScope) {

      //Addin record
        var vm = $scope;
         vm.user = {};
        vm.registerError = "";

      $scope.register = function() {
          console.log(vm.user);

          $http.post("http://localhost/myapp/public/api/v1/customers/signup",vm.user)
              .then (function(response){
                  console.log(JSON.stringify(response));
                              $rootScope.user = response;
                              if(response){

                                  $location.path("/login");
                              }

                          },function(response){

                              vm.loginError = "Something wrong";

                          });
              }
      }






    mainCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function mainCtrl($scope,$location,$http,$rootScope,API_URL) {

        //console.log(API_URL);
        //retrieve employees listing from API
        $http.get(API_URL + "employees")
            .success(function(response) {
                $scope.employees = response;
            });

        //show modal form
        $scope.toggle = function(modalstate, id) {
            $scope.modalstate = modalstate;

            switch (modalstate) {
                case 'add':
                    $scope.form_title = "Add New Employee";
                    break;
                case 'edit':
                    $scope.form_title = "Employee Detail";
                    $scope.id = id;
                    $http.get(API_URL + 'employees/' + id)
                        .success(function(response) {
                            console.log(response);
                            $scope.employee = response;
                        });
                    break;
                default:
                    break;
            }
            console.log(id);
            $('#myModal').modal('show');
        }

        //save new record / update existing record
        $scope.save = function(modalstate, id) {
            var url = API_URL + "employees";

            //append employee id to the URL if the form is in edit mode
            if (modalstate === 'edit'){
                url += "/" + id;
            }

            $http({
                method: 'POST',
                url: url,
                data: $.param($scope.employee),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).success(function(response) {
                console.log(response);
                location.reload();
            }).error(function(response) {
                console.log(response);
                alert('This is embarassing. An error has occured. Please check the log for details');
            });
        }

        //delete record
        $scope.confirmDelete = function(id) {
            var isConfirmDelete = confirm('Are you sure you want to delete this record?');

            if (isConfirmDelete) {
                $http({
                    method: 'DELETE',
                    url: API_URL + 'employees/' + id
                }).
                success(function(data) {
                    console.log(data);
                    location.reload();
                }).
                error(function(data) {
                    console.log(data);
                    alert('Unable to delete');
                });
            } else {
                return false;
            }
        }

    };


    })();
