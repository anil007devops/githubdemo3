
(function() {
    'use strict';
    angular
        .module('bookWishlistApp',  ['ui.router','ngCookies']);




})();