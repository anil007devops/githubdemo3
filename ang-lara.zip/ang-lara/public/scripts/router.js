(function (){

'use strict';

angular
.module('bookWishlistApp')
.config(config);

config.$inject = ['$stateProvider','$urlRouterProvider'];
function config ($stateProvider,$urlRouterProvider){


  $urlRouterProvider
      .otherwise('/');

  $stateProvider

      .state('login',{
        url:'/login',
        templateUrl:'partials/login.html',
        controller:'LoginController',

      })

      .state('signup',{
        url:'/signup',
        templateUrl:'partials/signup.html',
        controller:'SignupController',

      })

      .state('/',{
        url:'/',
        templateUrl:'partials/index.html',
        controller:'',

      })

      .state('/about',{
        url:'/about',
        templateUrl:'partials/about.html',
        controller:'',

      })

      .state('/blog',{
        url:'/blog',
        templateUrl:'partials/blog.html',
        controller:'',

      })
      .state('/contact',{
        url:'/contact',
        templateUrl:'partials/contact.html',
        controller:'',

      })

}

})();
