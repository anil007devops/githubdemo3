

<?php
session_start();


$email = $_SESSION['email'];
$password = $_SESSION['password'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "copierguru";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, email, password FROM admin where email = $email && password = $password";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Email: " . $row["email"]. " -Password" . $row["password"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();

?>