<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('index');
});


// Route::get('/api/v1/employees/{id?}', 'Employees@index');
//Route::post('/api/v1/customers/signup', 'CustomerController@store');
//Route::get('/api/v1/customers/login');
//
Route::post('auth','AdminController@postLogin');
Route::resource('user','AdminController');
//Route::post('/api/v1/customers/login', 'AdminController@postLogin');
//Route::get('/admin/login','AdminController@getLogin')->name('admin.login2');

//
//
//Route::get('/login2',function(){
//   return view('login2');
//})->name('login2');  // it will redirect to login page
//
//Route::get('/admin',function(){
//   return view('admin.adminDashboard');
//})->name('adminDashboard'); // it will redirect to dashboard


//Route::post('/login','AdminController@postLogin')->name('admin.login2'); // this will be used when post action performed in form.
//Route::post('/admin','AdminController@getIndex')->name('adminDashboard');
//Route::post('/about')->name('about');
// Route::post('/api/v1/employees/{id}', 'Employees@update');
// Route::delete('/api/v1/employees/{id}', 'Employees@destroy');

?>
