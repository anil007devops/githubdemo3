<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::group(['middleware'=>['web']],function() {

    Route::get('/','PostController@getBlogIndex')->name('blog.index');
    Route::get('/blog','PostController@getBlogIndex')->name('blog.index');
    Route::get('/blog/posts','PostController@getPostIndex')->name('admin.blog.index');
    Route::get('/blog/categories','CategoryController@getCategoryIndex')->name('admin.blog.categories');
    Route::get('/blog/post/{post_id}&{end}','PostController@getSinglePost')->name('admin.blog.post');
    Route::get('/blog/{post_id}&{end}','PostController@getSinglePost')->name('blog.single');
    Route::post('/contact/sendmail','ContactMessageController@postSendMessage')->name('contact.send');

    //other routes
    Route::get('/about',function (){
    return view('frontend.other.about');
})->name('about');

     Route::get('/contact','ContactMessageController@getContactIndex')->name('contact');



    Route::post('/admin/blog/category/create','CategoryController@postCreateCategory')->name('admin.blog.category.create');
    Route::get('/blog.posts/create','PostController@getCreatePost')->name('admin.blog.create_post');

    Route::get('/blog/post/{post_id}/edit','PostController@getUpdatePost')->name('admin.blog.post.edit');
    Route::post('/blog/post/update','PostController@postUpdatePost')->name('admin.blog.post.update');
    Route::post('/admin/blog/categories/update','CategoryController@postUpdateCategory')->name('admin.blog.category.update');
    Route::get('/blog/post/{post_id}/delete','PostController@getDeletePost')->name('admin.blog.post.delete');
    Route::get('/admin/blog/category/{category_id}/delete','CreateController@getDeleteCategory')->name('admin.blog.category.delete');
    Route::post('/blog/post/create','PostController@postCreatePost')->name('admin.blog.post.create');
    Route::get('/contact/messages','ContactMessageController@getContactMessageIndex')->name('admin.contact.index');
    Route::get('/admin/contact/message/{message_id}/delete','ContactMessageController@getDeleteMessage')->name('admin.contact.delete');


});

Route::get('/admin/login','AdminController@getLogin')->name('admin.login');
Route::post('/admin/login','AdminController@postLogin')->name('admin.login');

Route::group([
    'prefix'=>'/admin',

],function (){
    Route::get('/','AdminController@getIndex')->name('admin.index');
    Route::get('/logout','AdminController@getLogout')->name('admin.logout');
});


//
//Route::get('/about',function (){
//   return view('frontend.other.about');
//});

// also we can define like below---

//Route::get('/{author?}',[
//
//    'uses'=> 'QuoteController@getIndex',
//    'as'=> 'index'
//]);
//
//
//Route::get('/delete{quote_id}',[
//
//    'uses'=> 'QuoteController@getDeleteQuote',
//    'as'=> 'delete'
//]);
//
//
//Route::post('/create',[
//
//    'uses'=> 'QuoteController@postQuote',
//    'as'=> 'create'
//]);
//

