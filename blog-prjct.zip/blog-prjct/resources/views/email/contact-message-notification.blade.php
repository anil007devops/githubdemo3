<h1>A new contact message sent</h1>
<h3>Information about your mail</h3>
<p>Subject: {{ $contact_message->subject }}</p>
<p>Message : {{ $contact_message->body }}</p>