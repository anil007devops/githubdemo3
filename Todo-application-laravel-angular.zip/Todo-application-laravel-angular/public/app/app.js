var app = angular.module('employeeRecords', [])
    .constant('API_URL', 'http://localhost/myapp/public/api/v1/');
