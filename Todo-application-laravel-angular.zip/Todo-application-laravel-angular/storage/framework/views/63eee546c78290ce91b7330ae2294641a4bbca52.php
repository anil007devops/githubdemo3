<?php $__env->startSection('title'); ?>
    Tranding quotes
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php if(!empty(Request::segment(1))): ?>

<section class="filter-bar">
    A filter has been set! <a href="<?php echo e(route('index')); ?>">Show all quotes</a>

</section>
    <?php endif; ?>

<?php if(count($errors)>0): ?>

    <section class="info-box fail">

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </section>
    <?php endif; ?>

<?php if(Session::has('success')): ?>
<section class="info-box success">
    <?php echo e(Session::get('success')); ?>

</section>
<?php endif; ?>
   <section class="quotes">
<h1>Latest Quotes</h1>

       <?php for($i = 0; $i < count($quotes); $i++): ?>      <!-- here quotes is come from getIndex() method of QuoteController-->

           <article class="quote">
               <div class="delete"><a href="<?php echo e(route('delete',['quote_id'=> $quotes[$i]->id])); ?>">X</a></div>
             <?php echo e($quotes[$i]->quote); ?>   <!-- here quote is the property stored in quote table -->
               <div class="info">Created by <a href="<?php echo e(route('index',['author'=>$quotes[$i]->author->name])); ?>"><?php echo e($quotes[$i]->author->name); ?></a> on <?php echo e($quotes[$i]->created_at); ?></div> <!--here author name is the property in database author -->
           </article>

           <?php endfor; ?>

       <div class="pagination">
<?php if($quotes->currentPage() !== 1): ?>
    <a href="<?php echo e($quotes->previousPageUrl()); ?>"><span class="fa fa-caret-left" style="font-size: 50px;"></span></a>
    <?php endif; ?>
           <?php if($quotes->currentPage() !== $quotes->lastPage() && $quotes->hasPages()): ?>
        <a href="<?php echo e($quotes->nextPageUrl()); ?>"><span class="fa fa-caret-right" style="font-size: 50px;"></span></a>
               <?php endif; ?>
       </div>
   </section>

   <section class="edit-quote">
<h1>Add a Quote</h1>
       <form action="<?php echo e(route('create')); ?>" method="post">

           <div class="input-group">
               <label for="author">Your Name</label>
               <input type="text" name="author" id="author" placeholder="Your name"/>
           </div>

           <div class="input-group">
               <label for="author">Your Email</label>
               <input type="email" name="email" id="email" placeholder="Your Email"/>
           </div>

           <div class="input-group">
               <label for="quote">Your Quote</label>
               <textarea name="quote" id="quote" rows="5" placeholder="Quote"></textarea>
           </div>

<button type="submit" class="btn">Submit Quote</button>
           <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">

       </form>
   </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>